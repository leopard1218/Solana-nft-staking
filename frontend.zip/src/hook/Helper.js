export const getImg = (img) => {
    return require(`../assets/${img}`).default
}